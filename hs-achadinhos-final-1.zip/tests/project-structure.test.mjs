import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

const root = process.cwd();
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

test("o projeto não contém versões antigas ou patches", () => {
  const result = spawnSync(process.execPath, ["scripts/project-audit.mjs"], { cwd: root, encoding: "utf8" });
  assert.equal(result.status, 0, result.stderr || result.stdout);
});

test("o catálogo carrega seis produtos e oferece paginação incremental", () => {
  const source = read("src/components/ProductExplorer.tsx");
  assert.match(source, /pageSize\s*=\s*6/);
  assert.match(source, /page \+ 1/);
  assert.match(source, /Ver mais produtos/);
});

test("o coverflow possui autoplay pausável e pré-carregamento", () => {
  const source = read("src/components/HeroProductCarousel.tsx");
  assert.match(source, /setTimeout/);
  assert.doesNotMatch(source, /setInterval/);
  assert.match(source, /visibilitychange/);
  assert.match(source, /IntersectionObserver/);
  assert.match(source, /preloadProductImage/);
});

test("o footer mobile usa grupos recolhíveis acessíveis", () => {
  const source = read("src/components/Footer.tsx");
  assert.match(source, /aria-expanded/);
  assert.match(source, /aria-controls/);
  assert.match(source, /Explorar/);
  assert.match(source, /Categorias/);
  assert.match(source, /Informações/);
});

test("consultas públicas não incluem notas internas", () => {
  const source = read("src/lib/catalog.ts");
  const declaration = source.match(/PUBLIC_PRODUCT_SELECT\s*=\s*"([^"]+)"/)?.[1] || "";
  assert.ok(declaration);
  assert.equal(declaration.includes("internal_notes"), false);
});
