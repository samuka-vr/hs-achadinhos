"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { MouseEvent as ReactMouseEvent, PointerEvent as ReactPointerEvent } from "react";
import type { Product } from "@/lib/types";
import { getProductPriceDisplay } from "@/lib/utils";
import Icon from "./Icon";
import SafeProductImage from "./SafeProductImage";

const PAUSE_AFTER_INTERACTION = 4200;

type MouseDrag = {
  pointerId: number;
  startX: number;
  startScrollLeft: number;
  moved: boolean;
};

export default function HeroProductCarousel({ products, interval = 5200 }: { products: Product[]; interval?: number }) {
  const slides = useMemo(() => products.filter((item) => Boolean(item.image_url?.trim())).slice(0, 40), [products]);
  const viewportRef = useRef<HTMLDivElement>(null);
  const resumeTimerRef = useRef<number | null>(null);
  const scrollTimerRef = useRef<number | null>(null);
  const mouseDragRef = useRef<MouseDrag | null>(null);
  const suppressClickRef = useRef(false);
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const [pageVisible, setPageVisible] = useState(true);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [mouseDragging, setMouseDragging] = useState(false);

  const scheduleResume = useCallback(() => {
    setPaused(true);
    if (resumeTimerRef.current) window.clearTimeout(resumeTimerRef.current);
    resumeTimerRef.current = window.setTimeout(() => setPaused(false), PAUSE_AFTER_INTERACTION);
  }, []);

  const scrollToIndex = useCallback((target: number, behavior: ScrollBehavior = "smooth") => {
    const viewport = viewportRef.current;
    if (!viewport || !slides.length) return;
    const normalized = (target + slides.length) % slides.length;
    viewport.scrollTo({ left: normalized * viewport.clientWidth, behavior: reducedMotion ? "auto" : behavior });
    setIndex(normalized);
  }, [reducedMotion, slides.length]);

  useEffect(() => {
    if (index >= slides.length) {
      setIndex(0);
      viewportRef.current?.scrollTo({ left: 0, behavior: "auto" });
    }
  }, [index, slides.length]);

  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const syncMotion = () => setReducedMotion(media.matches);
    const syncVisibility = () => setPageVisible(document.visibilityState === "visible");
    syncMotion();
    syncVisibility();
    media.addEventListener?.("change", syncMotion);
    document.addEventListener("visibilitychange", syncVisibility);
    return () => {
      media.removeEventListener?.("change", syncMotion);
      document.removeEventListener("visibilitychange", syncVisibility);
    };
  }, []);

  useEffect(() => () => {
    if (resumeTimerRef.current) window.clearTimeout(resumeTimerRef.current);
    if (scrollTimerRef.current) window.clearTimeout(scrollTimerRef.current);
  }, []);

  useEffect(() => {
    if (paused || reducedMotion || !pageVisible || slides.length < 2) return;
    const timer = window.setTimeout(() => scrollToIndex(index + 1), Math.max(3800, interval));
    return () => window.clearTimeout(timer);
  }, [index, interval, pageVisible, paused, reducedMotion, scrollToIndex, slides.length]);

  function syncIndexFromScroll() {
    const viewport = viewportRef.current;
    if (!viewport || !viewport.clientWidth) return;
    if (scrollTimerRef.current) window.clearTimeout(scrollTimerRef.current);
    scrollTimerRef.current = window.setTimeout(() => {
      const next = Math.max(0, Math.min(slides.length - 1, Math.round(viewport.scrollLeft / viewport.clientWidth)));
      setIndex(next);
    }, 70);
  }

  function onPointerDown(event: ReactPointerEvent<HTMLDivElement>) {
    scheduleResume();
    if (event.pointerType !== "mouse" || event.button !== 0) return;
    const viewport = viewportRef.current;
    if (!viewport) return;
    mouseDragRef.current = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startScrollLeft: viewport.scrollLeft,
      moved: false,
    };
    setMouseDragging(true);
    viewport.setPointerCapture?.(event.pointerId);
  }

  function onPointerMove(event: ReactPointerEvent<HTMLDivElement>) {
    const drag = mouseDragRef.current;
    const viewport = viewportRef.current;
    if (!drag || !viewport || drag.pointerId !== event.pointerId) return;
    const delta = event.clientX - drag.startX;
    if (Math.abs(delta) > 5) {
      drag.moved = true;
      suppressClickRef.current = true;
    }
    viewport.scrollLeft = drag.startScrollLeft - delta;
  }

  function finishMouseDrag(event: ReactPointerEvent<HTMLDivElement>) {
    const drag = mouseDragRef.current;
    const viewport = viewportRef.current;
    if (!drag || !viewport || drag.pointerId !== event.pointerId) return;
    mouseDragRef.current = null;
    setMouseDragging(false);
    const next = Math.max(0, Math.min(slides.length - 1, Math.round(viewport.scrollLeft / Math.max(1, viewport.clientWidth))));
    scrollToIndex(next);
  }

  function preventClick(event: ReactMouseEvent<HTMLDivElement>) {
    if (!suppressClickRef.current) return;
    event.preventDefault();
    event.stopPropagation();
    suppressClickRef.current = false;
  }

  if (!slides.length) {
    return <div className="hs-spotlight hs-spotlight--empty"><span><Icon name="sparkles" /></span><strong>Novos destaques em breve</strong><p>Os produtos com imagem aparecem aqui automaticamente.</p></div>;
  }

  return (
    <section className="hs-spotlight" aria-roledescription="carrossel" aria-label="Produtos em destaque">
      <div
        ref={viewportRef}
        className={`hs-spotlight__viewport ${mouseDragging ? "is-dragging" : ""}`}
        onScroll={syncIndexFromScroll}
        onTouchStart={scheduleResume}
        onTouchEnd={scheduleResume}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={finishMouseDrag}
        onPointerCancel={finishMouseDrag}
        onClickCapture={preventClick}
      >
        {slides.map((product, slideIndex) => {
          const price = getProductPriceDisplay(product);
          return (
            <article className="hs-spotlight__slide" key={product.id} aria-hidden={slideIndex !== index}>
              <div className="hs-spotlight__card">
                <Link href={`/produto/${product.slug}`} className="hs-spotlight__media" aria-label={`Abrir ${product.name}`} tabIndex={slideIndex === index ? 0 : -1}>
                  <SafeProductImage src={product.image_url} alt={product.name} />
                  <span>{product.is_video_product ? "Visto no vídeo" : "Achado em destaque"}</span>
                </Link>
                <div className="hs-spotlight__content">
                  <div className="hs-spotlight__meta"><span>{product.categories?.name || "Achadinho"}</span>{product.product_code ? <b>{product.product_code}</b> : null}</div>
                  <h2>{product.name}</h2>
                  <div className="hs-spotlight__price"><strong>{price.main}</strong>{price.secondary ? <del>{price.secondary}</del> : null}</div>
                  <div className="hs-spotlight__actions">
                    <Link href={`/produto/${product.slug}`} tabIndex={slideIndex === index ? 0 : -1}>Ver detalhes</Link>
                    <a href={`/go/${product.id}`} target="_blank" rel="nofollow sponsored noopener" tabIndex={slideIndex === index ? 0 : -1}>Abrir na Shopee <Icon name="external" size={16} /></a>
                  </div>
                </div>
              </div>
            </article>
          );
        })}
      </div>
      {slides.length > 1 ? <div className="hs-spotlight__controls">
        <button type="button" onClick={() => { scheduleResume(); scrollToIndex(index - 1); }} aria-label="Produto anterior"><Icon name="arrow" /></button>
        <div className="hs-spotlight__progress"><span style={{ width: `${((index + 1) / slides.length) * 100}%` }} /><small>{String(index + 1).padStart(2, "0")} / {String(slides.length).padStart(2, "0")}</small></div>
        <button type="button" onClick={() => { scheduleResume(); scrollToIndex(index + 1); }} aria-label="Próximo produto"><Icon name="arrow" /></button>
      </div> : null}
    </section>
  );
}
