import type { Metadata } from "next";
import CategoryStories from "@/components/CategoryStories";
import Icon from "@/components/Icon";
import ProductExplorer from "@/components/ProductExplorer";
import SearchBox from "@/components/SearchBox";
import { getServerSupabase } from "@/lib/supabase/server";
import type { Category, Product } from "@/lib/types";
import { parseSettings } from "@/lib/utils";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Catálogo completo",
  description: "Veja todos os achadinhos, filtre por categoria e encontre o produto pelo nome ou código.",
};

export default async function CatalogPage() {
  const supabase = getServerSupabase();
  let products: Product[] = [];
  let categories: Category[] = [];
  let pageSize = 12;

  if (supabase) {
    const [productResult, categoryResult, settingsResult] = await Promise.all([
      supabase.from("products").select("*,categories(id,name,slug)").eq("is_active", true).order("is_pinned", { ascending: false }).order("created_at", { ascending: false }).limit(500),
      supabase.from("categories").select("*").eq("is_active", true).order("sort_order").order("name"),
      supabase.from("site_settings").select("key,value"),
    ]);
    products = (productResult.data ?? []) as Product[];
    categories = (categoryResult.data ?? []) as Category[];
    const settings = parseSettings(settingsResult.data);
    pageSize = Math.min(Math.max(settings.products_per_page || 12, 8), 12);
  }

  return (
    <main className="hs-inner-page hs-catalog-page">
      <div className="hs-shell">
        <section className="hs-catalog-page__hero">
          <span className="hs-catalog-page__eyebrow"><Icon name="products" size={16} /> CATÁLOGO COMPLETO</span>
          <div>
            <h1>Todos os produtos</h1>
            <p>Pesquise pelo nome ou código, escolha uma categoria e veja apenas o que interessa.</p>
          </div>
          <SearchBox />
        </section>

        {categories.length ? (
          <section className="hs-catalog-page__categories" aria-labelledby="catalog-categories-title">
            <header>
              <div><span>ATALHOS</span><h2 id="catalog-categories-title">Categorias</h2></div>
              <small>{categories.length} categorias</small>
            </header>
            <CategoryStories categories={categories} />
          </section>
        ) : null}

        <section className="hs-catalog-page__products" aria-labelledby="catalog-products-title">
          <header className="hs-section-heading">
            <div><span>EXPLORE OS ACHADOS</span><h2 id="catalog-products-title">Encontre o produto certo</h2><p>Use os filtros e carregue mais produtos aos poucos.</p></div>
          </header>
          <ProductExplorer products={products} categories={categories} pageSize={pageSize} />
        </section>
      </div>
    </main>
  );
}
