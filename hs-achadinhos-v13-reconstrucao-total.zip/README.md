# H&S Achadinhos — Galeria de Descobertas + H&S Studio

Reconstrução total da camada visual pública e administrativa do H&S Achadinhos.

Esta versão preserva os mecanismos existentes — Supabase, autenticação, banco, produtos, categorias, busca, importador, uploads, links da Shopee, analytics, rotas e regras de negócio — e substitui a apresentação por dois sistemas visuais novos.

## Site público: Galeria de Descobertas

- mobile-first desde 360 px;
- header e menu completamente novos;
- hero centrado na busca por nome ou código;
- carrossel reconstruído com um produto completo por vez no celular;
- categorias maiores e legíveis;
- cards de produtos com nome, categoria, código, preço e ações;
- catálogo, busca e página de produto reformulados;
- footer e redes sociais com identidade própria;
- estados de carregamento, vazio, erro e imagem ausente.

## Painel: H&S Studio

- shell e navegação novos;
- dashboard orientado a tarefas;
- produtos em cartões também no desktop, sem tabela reaproveitada;
- navegação inferior e menu em gaveta no celular;
- editor de produto em tela cheia no mobile;
- troca rápida de imagem;
- importação, categorias, mídia, editor da home, banners, redes, aparência, analytics, atividades e configurações com o novo design system;
- login administrativo reconstruído.

## Stack preservada

- Next.js 15
- React 19
- TypeScript
- Supabase Auth, Database e Storage
- Vercel

## Aplicação

Não é necessário executar SQL. Esta versão não altera tabelas nem dados.

Consulte `ATUALIZACAO-V13-RECONSTRUCAO-TOTAL.md` para aplicar a atualização pelo Codespaces.

## Validações realizadas no pacote

- 64 arquivos TypeScript/TSX lidos pelo compilador TypeScript sem erro de sintaxe;
- arquivos JSON validados;
- estrutura dos três arquivos CSS validada;
- imports dos estilos antigos removidos;
- arquivos CSS antigos retirados do projeto completo;
- nenhum SQL ou dado do Supabase modificado.

O `npm install`, o `typecheck` e o `build` completos não puderam ser executados no ambiente de geração porque o registro npm interno não disponibilizou `@supabase/supabase-js`. Eles devem ser executados no Codespaces antes do push.
