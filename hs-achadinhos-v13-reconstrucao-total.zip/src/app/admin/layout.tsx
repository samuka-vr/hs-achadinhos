import "../styles/studio-v13.css";

export default function AdminRootLayout({ children }: { children: React.ReactNode }) {
  return children;
}
