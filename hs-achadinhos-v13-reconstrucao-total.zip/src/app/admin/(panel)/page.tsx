"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import ClicksChart, { type ChartPoint } from "@/components/ClicksChart";
import Icon from "@/components/Icon";
import { getBrowserSupabase } from "@/lib/supabase/client";

type ProductRow = {
  id: string;
  name: string;
  image_url: string | null;
  click_count: number;
  is_active: boolean;
  is_video_product: boolean;
  product_code: string | null;
  affiliate_url: string;
  categories: { name: string } | null;
};
type ClickRow = { clicked_at: string };
type SearchRow = { query: string; results_count: number; searched_at: string };
type ViewRow = { viewed_at: string };

export default function AdminDashboardPage() {
  const [products, setProducts] = useState<ProductRow[]>([]);
  const [categoryCount, setCategoryCount] = useState(0);
  const [clicks, setClicks] = useState<ClickRow[]>([]);
  const [searches, setSearches] = useState<SearchRow[]>([]);
  const [views, setViews] = useState<ViewRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const supabase = getBrowserSupabase();
    if (!supabase) return;
    void (async () => {
      const since = new Date();
      since.setDate(since.getDate() - 29);
      const [productResult, categoryResult, clickResult, searchResult, viewResult] = await Promise.all([
        supabase.from("products").select("id,name,image_url,click_count,is_active,is_video_product,product_code,affiliate_url,categories(name)").order("click_count", { ascending: false }),
        supabase.from("categories").select("id", { count: "exact", head: true }).eq("is_active", true),
        supabase.from("product_clicks").select("clicked_at").gte("clicked_at", since.toISOString()),
        supabase.from("search_events").select("query,results_count,searched_at").gte("searched_at", since.toISOString()),
        supabase.from("page_views").select("viewed_at").gte("viewed_at", since.toISOString()),
      ]);
      if (productResult.error) setError("Alguns dados não puderam ser carregados.");
      setProducts((productResult.data ?? []) as unknown as ProductRow[]);
      setCategoryCount(categoryResult.count ?? 0);
      setClicks((clickResult.data ?? []) as ClickRow[]);
      setSearches((searchResult.data ?? []) as SearchRow[]);
      setViews((viewResult.data ?? []) as ViewRow[]);
      setLoading(false);
    })();
  }, []);

  const stats = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const seven = new Date(today);
    seven.setDate(seven.getDate() - 6);
    const points: ChartPoint[] = [];
    for (let dayOffset = 29; dayOffset >= 0; dayOffset -= 1) {
      const day = new Date(today);
      day.setDate(day.getDate() - dayOffset);
      const key = day.toISOString().slice(0, 10);
      points.push({ date: key, clicks: clicks.filter((item) => item.clicked_at.slice(0, 10) === key).length });
    }
    const queries = new Map<string, number>();
    searches.forEach((item) => queries.set(item.query.toLowerCase(), (queries.get(item.query.toLowerCase()) || 0) + 1));
    return {
      todayClicks: clicks.filter((item) => new Date(item.clicked_at) >= today).length,
      sevenClicks: clicks.filter((item) => new Date(item.clicked_at) >= seven).length,
      todayViews: views.filter((item) => new Date(item.viewed_at) >= today).length,
      zeroSearches: searches.filter((item) => item.results_count === 0).length,
      points,
      topQueries: [...queries.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6),
    };
  }, [clicks, searches, views]);

  if (loading) return <div className="hst-inline-loading"><span /><strong>Organizando seus dados...</strong></div>;

  const published = products.filter((product) => product.is_active).length;
  const drafts = products.length - published;
  const missingImages = products.filter((product) => !product.image_url);
  const linkProblems = products.filter((product) => !product.affiliate_url);
  const problems = products.filter((product) => !product.image_url || !product.affiliate_url || !product.product_code);

  return (
    <>
      <section className="hst-dashboard-hero">
        <div>
          <span>HOJE NO H&S STUDIO</span>
          <h1>O que precisa da sua atenção?</h1>
          <p>Comece pelas tarefas importantes e publique novos achadinhos sem se perder.</p>
        </div>
        <div className="hst-dashboard-hero-actions">
          <Link href="/admin/produtos/importar"><Icon name="code" />Importar lista</Link>
          <Link href="/admin/produtos"><Icon name="plus" />Novo produto</Link>
        </div>
      </section>

      {error ? <div className="hst-alert is-error">{error}</div> : null}

      <section className="hst-priority-strip">
        <Link href="/admin/produtos" className={missingImages.length ? "is-warning" : "is-good"}>
          <span><Icon name="image" /></span>
          <div><small>Sem imagem</small><strong>{missingImages.length}</strong></div>
          <Icon name="arrow" size={16} />
        </Link>
        <Link href="/admin/produtos" className={drafts ? "is-soft" : "is-good"}>
          <span><Icon name="text" /></span>
          <div><small>Rascunhos</small><strong>{drafts}</strong></div>
          <Icon name="arrow" size={16} />
        </Link>
        <Link href="/admin/produtos" className={linkProblems.length ? "is-danger" : "is-good"}>
          <span><Icon name="link" /></span>
          <div><small>Links com problema</small><strong>{linkProblems.length}</strong></div>
          <Icon name="arrow" size={16} />
        </Link>
      </section>

      <section className="hst-metrics-grid">
        <article><span className="is-coral"><Icon name="products" /></span><div><small>Publicados</small><strong>{published}</strong><em>{products.length} cadastrados</em></div></article>
        <article><span className="is-sage"><Icon name="eye" /></span><div><small>Visitas hoje</small><strong>{stats.todayViews}</strong><em>acessos ao site</em></div></article>
        <article><span className="is-lilac"><Icon name="click" /></span><div><small>Cliques hoje</small><strong>{stats.todayClicks}</strong><em>{stats.sevenClicks} em 7 dias</em></div></article>
        <article><span className="is-butter"><Icon name="search" /></span><div><small>Buscas sem resultado</small><strong>{stats.zeroSearches}</strong><em>termos para revisar</em></div></article>
      </section>

      <section className="hst-dashboard-layout">
        <article className="hst-panel hst-task-panel">
          <header><div><span>PRÓXIMOS PASSOS</span><h2>Tarefas do catálogo</h2></div><b>{problems.length}</b></header>
          <div className="hst-task-list">
            {problems.slice(0, 6).map((product) => (
              <Link href="/admin/produtos" key={product.id}>
                <span><Icon name={!product.image_url ? "image" : !product.product_code ? "code" : "link"} /></span>
                <div><strong>{product.name}</strong><small>{!product.image_url ? "Adicionar uma imagem" : !product.product_code ? "Adicionar o código do vídeo" : "Revisar o link"}</small></div>
                <Icon name="arrow" size={16} />
              </Link>
            ))}
            {!problems.length ? <div className="hst-all-good"><Icon name="check" /><div><strong>Tudo organizado.</strong><small>Nenhuma pendência no catálogo.</small></div></div> : null}
          </div>
        </article>

        <article className="hst-panel hst-shortcuts-panel">
          <header><div><span>ATALHOS</span><h2>Edite sem perder tempo</h2></div></header>
          <div className="hst-shortcut-grid">
            <Link href="/admin/produtos"><span><Icon name="products" /></span><strong>Produtos</strong><small>Fotos, preços e links</small></Link>
            <Link href="/admin/editor"><span><Icon name="layout" /></span><strong>Página inicial</strong><small>Seções e ordem</small></Link>
            <Link href="/admin/aparencia"><span><Icon name="palette" /></span><strong>Aparência</strong><small>Marca e componentes</small></Link>
            <Link href="/admin/navegacao"><span><Icon name="navigation" /></span><strong>Redes sociais</strong><small>Links e menus</small></Link>
          </div>
        </article>

        <article className="hst-panel hst-chart-panel">
          <header><div><span>ÚLTIMOS 30 DIAS</span><h2>Cliques para a Shopee</h2></div><Link href="/admin/analytics">Ver analytics <Icon name="arrow" size={15} /></Link></header>
          <ClicksChart data={stats.points} />
        </article>
      </section>

      <section className="hst-dashboard-lower">
        <article className="hst-panel">
          <header><div><span>MAIS ACESSADOS</span><h2>Produtos que chamam atenção</h2></div><Link href="/admin/produtos">Ver produtos</Link></header>
          <div className="hst-ranking-list">
            {products.slice(0, 6).map((product, index) => (
              <div key={product.id}>
                <b>{String(index + 1).padStart(2, "0")}</b>
                {product.image_url ? <img src={product.image_url} alt="" /> : <span><Icon name="image" size={17} /></span>}
                <div><strong>{product.name}</strong><small>{product.product_code ? `Código ${product.product_code}` : product.categories?.name || "Sem categoria"}</small></div>
                <em>{product.click_count}</em>
              </div>
            ))}
          </div>
        </article>

        <article className="hst-panel">
          <header><div><span>PESQUISAS</span><h2>O que as pessoas procuram</h2></div><Link href="/admin/analytics">Detalhes</Link></header>
          <div className="hst-query-list">
            {stats.topQueries.map(([query, count]) => <div key={query}><strong>{query}</strong><span>{count}</span></div>)}
          </div>
          {!stats.topQueries.length ? <div className="hst-empty-mini">Ainda não há pesquisas registradas.</div> : null}
        </article>
      </section>

      <footer className="hst-dashboard-footer"><span><Icon name="categories" />{categoryCount} categorias ativas</span><span><Icon name="products" />{products.length} produtos cadastrados</span></footer>
    </>
  );
}
