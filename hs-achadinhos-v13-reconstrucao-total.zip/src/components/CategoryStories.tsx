import Link from "next/link";
import type { CSSProperties } from "react";
import type { Category } from "@/lib/types";
import Icon from "./Icon";

function initials(name: string) {
  return name
    .split(/\s|&/)
    .map((part) => part.trim())
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
}

export default function CategoryStories({
  categories,
  variant = "stories",
}: {
  categories: Category[];
  variant?: "stories" | "cards";
}) {
  if (!categories.length) return null;

  return (
    <div className={`gallery-category-grid gallery-category-grid-${variant}`} aria-label="Categorias">
      {categories.map((category, index) => (
        <Link
          href={`/categoria/${category.slug}`}
          key={category.id}
          style={{ "--category-accent": category.accent_color || "#d96c78" } as CSSProperties}
        >
          <span className="gallery-category-number">{String(index + 1).padStart(2, "0")}</span>
          <span className="gallery-category-media">
            {category.image_url ? (
              <img src={category.image_url} alt="" />
            ) : (
              <span className="gallery-category-initials">{initials(category.name)}</span>
            )}
          </span>
          <span className="gallery-category-copy">
            <strong>{category.name}</strong>
            <small>{category.description || "Veja os achados desta categoria"}</small>
            <em>Explorar <Icon name="arrow" size={15} /></em>
          </span>
        </Link>
      ))}
    </div>
  );
}
