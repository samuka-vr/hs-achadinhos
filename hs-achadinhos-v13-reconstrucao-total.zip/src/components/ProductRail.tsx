"use client";

import { useEffect, useRef, useState } from "react";
import type { Product } from "@/lib/types";
import ProductCard from "./ProductCard";
import Icon from "./Icon";

export default function ProductRail({
  products,
  autoplay = true,
  interval = 4200,
}: {
  products: Product[];
  autoplay?: boolean;
  interval?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [paused, setPaused] = useState(false);

  function move(direction: number) {
    const node = ref.current;
    if (!node) return;
    node.scrollBy({ left: direction * Math.min(node.clientWidth * 0.9, 420), behavior: "smooth" });
  }

  useEffect(() => {
    if (!autoplay || paused || products.length < 3) return;
    const timer = window.setInterval(() => {
      const node = ref.current;
      if (!node) return;
      const atEnd = node.scrollLeft + node.clientWidth >= node.scrollWidth - 20;
      if (atEnd) node.scrollTo({ left: 0, behavior: "smooth" });
      else move(1);
    }, Math.max(3600, interval));
    return () => window.clearInterval(timer);
  }, [autoplay, paused, interval, products.length]);

  return (
    <div
      className="gallery-product-rail-shell"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocusCapture={() => setPaused(true)}
      onBlurCapture={() => setPaused(false)}
    >
      <button className="gallery-rail-arrow is-left" onClick={() => move(-1)} aria-label="Produtos anteriores"><Icon name="arrow" /></button>
      <div className="gallery-product-rail" ref={ref}>
        {products.map((product) => <ProductCard key={product.id} product={product} />)}
      </div>
      <button className="gallery-rail-arrow is-right" onClick={() => move(1)} aria-label="Próximos produtos"><Icon name="arrow" /></button>
    </div>
  );
}
