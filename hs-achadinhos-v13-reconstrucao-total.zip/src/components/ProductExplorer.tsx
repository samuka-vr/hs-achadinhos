"use client";

import { useMemo, useState } from "react";
import type { Category, Product } from "@/lib/types";
import { normalizeSearch } from "@/lib/utils";
import ProductGrid from "./ProductGrid";
import Icon from "./Icon";

export default function ProductExplorer({
  products,
  categories,
  pageSize,
  showSearch = true,
}: {
  products: Product[];
  categories: Category[];
  pageSize: number;
  showSearch?: boolean;
}) {
  const [category, setCategory] = useState("all");
  const [sort, setSort] = useState("recent");
  const [term, setTerm] = useState("");
  const [visible, setVisible] = useState(pageSize);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const filtered = useMemo(() => {
    const normalized = normalizeSearch(term);
    const list = products.filter((product) => {
      const matchCategory = category === "all" || product.category_id === category;
      const text = normalizeSearch([
        product.name,
        product.product_code || "",
        product.short_description || "",
        product.categories?.name || "",
        ...(product.tags || []),
      ].join(" "));
      return matchCategory && (!normalized || text.includes(normalized));
    });

    switch (sort) {
      case "popular":
        return [...list].sort((a, b) => b.click_count - a.click_count);
      case "price-low":
        return [...list].sort((a, b) => (a.current_price ?? Number.MAX_SAFE_INTEGER) - (b.current_price ?? Number.MAX_SAFE_INTEGER));
      case "price-high":
        return [...list].sort((a, b) => (b.current_price ?? -1) - (a.current_price ?? -1));
      default:
        return [...list].sort((a, b) => Number(b.is_pinned) - Number(a.is_pinned) || new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    }
  }, [products, category, sort, term]);

  function resetPage() {
    setVisible(pageSize);
  }

  return (
    <div className="gallery-catalog-explorer">
      <div className={`gallery-catalog-toolbar ${showSearch ? "" : "without-search"}`}>
        {showSearch ? (
          <label className="gallery-catalog-search">
            <span className="sr-only">Filtrar produtos</span>
            <Icon name="search" />
            <input
              value={term}
              onChange={(event) => {
                setTerm(event.target.value);
                resetPage();
              }}
              placeholder="Filtrar por nome ou código"
            />
          </label>
        ) : null}
        <button className="gallery-filter-trigger" type="button" onClick={() => setFiltersOpen((value) => !value)} aria-expanded={filtersOpen}>
          <Icon name="settings" /> Filtros
        </button>
        <label className="gallery-sort-select">
          <span className="sr-only">Ordenar produtos</span>
          <select value={sort} onChange={(event) => setSort(event.target.value)}>
            <option value="recent">Mais recentes</option>
            <option value="popular">Mais acessados</option>
            <option value="price-low">Menor preço</option>
            <option value="price-high">Maior preço</option>
          </select>
          <Icon name="arrow" size={15} />
        </label>
      </div>

      <div className={`gallery-filter-panel ${filtersOpen ? "is-open" : ""}`}>
        <div className="gallery-category-tabs">
          <button className={category === "all" ? "active" : ""} onClick={() => { setCategory("all"); resetPage(); setFiltersOpen(false); }}>Todos</button>
          {categories.map((item) => (
            <button
              key={item.id}
              className={category === item.id ? "active" : ""}
              onClick={() => { setCategory(item.id); resetPage(); setFiltersOpen(false); }}
            >
              {item.name}
            </button>
          ))}
        </div>
      </div>

      <div className="gallery-catalog-count">
        <span><strong>{filtered.length}</strong> produto(s)</span>
        {(term || category !== "all") ? <button onClick={() => { setTerm(""); setCategory("all"); resetPage(); }}>Limpar filtros</button> : null}
      </div>

      <ProductGrid products={filtered.slice(0, visible)} />

      {visible < filtered.length ? (
        <div className="gallery-load-more">
          <button onClick={() => setVisible((value) => value + pageSize)}>Mostrar mais produtos</button>
        </div>
      ) : null}
    </div>
  );
}
