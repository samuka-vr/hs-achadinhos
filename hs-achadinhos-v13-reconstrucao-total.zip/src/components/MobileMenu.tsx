"use client";

import Link from "next/link";
import type { CSSProperties } from "react";
import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import type { Category, NavigationItem, SiteSettings } from "@/lib/types";
import Icon, { type IconName } from "./Icon";

export default function MobileMenu({
  categories,
  settings,
  navigation,
}: {
  categories: Category[];
  settings: SiteSettings;
  navigation: NavigationItem[];
}) {
  const [open, setOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const items = useMemo(
    () =>
      navigation
        .filter((item) => item.is_active && (item.location === "mobile" || item.location === "header"))
        .sort((a, b) => a.sort_order - b.sort_order),
    [navigation],
  );

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (!open) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    window.setTimeout(() => closeButtonRef.current?.focus(), 20);

    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", closeOnEscape);
      triggerRef.current?.focus();
    };
  }, [open]);

  const close = () => setOpen(false);
  const socialLinks = [
    ["instagram", settings.instagram, "Instagram"],
    ["tiktok", settings.tiktok, "TikTok"],
    ["store", settings.shopee_showcase, "Shopee"],
    ["whatsapp", settings.whatsapp, "WhatsApp"],
    ["youtube", settings.youtube, "YouTube"],
  ] as const;

  const fallbackItems = [
    { href: "/", label: "Início", icon: "home" as IconName },
    { href: "/#produtos-dos-videos", label: "Produtos dos vídeos", icon: "sparkles" as IconName },
    { href: "/#categorias", label: "Categorias", icon: "categories" as IconName },
    { href: "/#produtos", label: "Todos os produtos", icon: "products" as IconName },
  ];

  const menu = open ? (
    <div
      className="gallery-menu-layer"
      role="presentation"
      style={
        {
          "--brand": settings.primary_color,
          "--brand-soft": settings.secondary_color,
          "--surface": settings.surface_color,
          "--text": settings.text_color,
          "--muted": settings.muted_text_color,
          "--border": settings.border_color,
        } as CSSProperties
      }
    >
      <button className="gallery-menu-overlay" type="button" onClick={close} aria-label="Fechar menu" />
      <aside className="gallery-mobile-drawer" role="dialog" aria-modal="true" aria-label="Menu principal">
        <div className="gallery-drawer-handle" aria-hidden="true" />
        <div className="gallery-drawer-head">
          <Link href="/" className="gallery-drawer-brand" onClick={close}>
            <span><img src={settings.logo_url || "/brand/hs-monogram.svg"} alt="" /></span>
            <div>
              <strong>{settings.site_name}</strong>
              <small>{settings.header_tagline || "Viu no vídeo? Encontre aqui."}</small>
            </div>
          </Link>
          <button ref={closeButtonRef} type="button" onClick={close} aria-label="Fechar menu">
            <Icon name="close" />
          </button>
        </div>

        <div className="gallery-drawer-intro">
          <span>GALERIA H&S</span>
          <strong>O que você procura hoje?</strong>
          <p>Escolha um atalho ou encontre pelo código do vídeo.</p>
          <Link href="/busca" onClick={close}>
            <Icon name="search" /> Buscar produto
          </Link>
        </div>

        <nav className="gallery-drawer-links" aria-label="Links do menu">
          {items.length
            ? items.map((item, index) => (
                <Link href={item.url} key={item.id} onClick={close} target={item.open_new_tab ? "_blank" : undefined}>
                  <span className="gallery-drawer-link-icon"><Icon name={(item.icon || "link") as IconName} /></span>
                  <span><b>{item.label}</b><small>{String(index + 1).padStart(2, "0")}</small></span>
                  <Icon name="arrow" size={17} />
                </Link>
              ))
            : fallbackItems.map((item, index) => (
                <Link href={item.href} key={item.href} onClick={close}>
                  <span className="gallery-drawer-link-icon"><Icon name={item.icon} /></span>
                  <span><b>{item.label}</b><small>{String(index + 1).padStart(2, "0")}</small></span>
                  <Icon name="arrow" size={17} />
                </Link>
              ))}
        </nav>

        {categories.length ? (
          <section className="gallery-drawer-categories">
            <header>
              <strong>Categorias</strong>
              <small>Deslize para escolher</small>
            </header>
            <div>
              {categories.slice(0, 10).map((category) => (
                <Link
                  href={`/categoria/${category.slug}`}
                  key={category.id}
                  onClick={close}
                  style={{ "--category-accent": category.accent_color || "#d96c78" } as CSSProperties}
                >
                  <span>
                    {category.image_url ? (
                      <img src={category.image_url} alt="" />
                    ) : (
                      <b>{category.name.slice(0, 2).toUpperCase()}</b>
                    )}
                  </span>
                  <small>{category.name}</small>
                </Link>
              ))}
            </div>
          </section>
        ) : null}

        <div className="gallery-drawer-socials">
          {socialLinks
            .filter(([, url]) => Boolean(url))
            .map(([icon, url, label]) => (
              <a href={url} key={label} target="_blank" rel="noreferrer" aria-label={label}>
                <Icon name={icon} />
              </a>
            ))}
        </div>
      </aside>
    </div>
  ) : null;

  return (
    <>
      <button
        ref={triggerRef}
        className="gallery-menu-trigger"
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Abrir menu"
        aria-expanded={open}
      >
        <Icon name="menu" />
      </button>
      {mounted && menu ? createPortal(menu, document.body) : null}
    </>
  );
}
