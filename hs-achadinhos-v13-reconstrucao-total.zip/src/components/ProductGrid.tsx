import type { CSSProperties } from "react";
import type { Product } from "@/lib/types";
import ProductCard from "./ProductCard";
import Icon from "./Icon";

export default function ProductGrid({
  products,
  emptyTitle = "Nenhum produto encontrado",
  className = "",
  columns,
}: {
  products: Product[];
  emptyTitle?: string;
  className?: string;
  columns?: number;
}) {
  if (!products.length) {
    return (
      <div className="gallery-empty-state">
        <span><Icon name="products" size={30} /></span>
        <h3>{emptyTitle}</h3>
        <p>Ainda não encontramos produtos para mostrar aqui.</p>
      </div>
    );
  }

  const style = columns
    ? ({ "--section-columns": Math.max(1, Math.min(5, columns)) } as CSSProperties)
    : undefined;

  return (
    <div className={`gallery-product-grid ${className}`} style={style}>
      {products.map((product) => <ProductCard key={product.id} product={product} />)}
    </div>
  );
}
