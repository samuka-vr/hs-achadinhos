import Link from "next/link";
import type { Category, NavigationItem, SiteSettings } from "@/lib/types";
import Icon from "./Icon";

export default function Footer({ settings }: { settings: SiteSettings; categories: Category[]; navigation: NavigationItem[] }) {
  const socials = [
    ["instagram", settings.instagram, "Instagram"],
    ["tiktok", settings.tiktok, "TikTok"],
    ["store", settings.shopee_showcase, "Vitrine Shopee"],
    ["whatsapp", settings.whatsapp, "WhatsApp"],
    ["youtube", settings.youtube, "YouTube"],
    ["facebook", settings.facebook, "Facebook"],
    ["telegram", settings.telegram, "Telegram"],
  ] as const;
  const active = socials.filter(([, url]) => Boolean(url));

  return (
    <footer className="gallery-footer" aria-label="Rodapé">
      <div className="gallery-footer-ribbon" aria-hidden="true">
        <span>ACHADINHOS</span><span>VÍDEOS</span><span>CÓDIGOS</span><span>SHOPEE</span>
      </div>

      <div className="gallery-container gallery-footer-main">
        <section className="gallery-footer-brand">
          <div className="gallery-footer-lockup">
            <span><img src={settings.logo_url || "/brand/hs-monogram.svg"} alt="" /></span>
            <div>
              <strong>{settings.site_name || "H&S Achadinhos"}</strong>
              <small>Galeria de descobertas</small>
            </div>
          </div>
          <h2>Viu no vídeo?<br />Encontre aqui.</h2>
          <p>Produtos organizados para você chegar ao link certo sem perder tempo.</p>
        </section>

        <section className="gallery-footer-social">
          <span>ACOMPANHE A H&S</span>
          <h3>{settings.footer_social_title || "Novos vídeos, novos achados."}</h3>
          <p>{settings.footer_social_subtitle || "Siga as redes e encontre os links de tudo o que aparecer por lá."}</p>
          <nav aria-label="Redes sociais">
            {active.length ? (
              active.map(([name, url, label]) => (
                <a href={url} target="_blank" rel="noreferrer" key={name} aria-label={label}>
                  <Icon name={name} />
                  <span>{label}</span>
                </a>
              ))
            ) : (
              <span className="gallery-footer-empty">As redes serão adicionadas em breve.</span>
            )}
          </nav>
        </section>
      </div>

      <div className="gallery-container gallery-footer-bottom">
        <p>Os preços, frete e estoque são confirmados diretamente na Shopee.</p>
        <div>
          <Link href="/politica-de-privacidade">Privacidade</Link>
          <Link href="/termos-de-uso">Termos</Link>
          <Link href="/aviso-de-afiliado">Aviso de afiliado</Link>
        </div>
        <span>© {new Date().getFullYear()} {settings.site_name || "H&S Achadinhos"}</span>
      </div>
    </footer>
  );
}
