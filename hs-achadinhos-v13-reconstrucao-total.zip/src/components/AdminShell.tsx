"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { ReactNode, useEffect, useMemo, useState } from "react";
import { getBrowserSupabase } from "@/lib/supabase/client";
import Icon, { type IconName } from "./Icon";

type Group = "Início" | "Catálogo" | "Conteúdo" | "Crescimento" | "Sistema";
type NavItem = { href: string; label: string; description: string; icon: IconName; group: Group; keywords?: string };

const navItems: NavItem[] = [
  { href: "/admin", label: "Início", description: "Prioridades e atalhos", icon: "home", group: "Início", keywords: "dashboard métricas tarefas" },
  { href: "/admin/produtos", label: "Produtos", description: "Catálogo, fotos e preços", icon: "products", group: "Catálogo", keywords: "rascunho publicar link foto" },
  { href: "/admin/produtos/importar", label: "Importação", description: "Cadastre vários de uma vez", icon: "code", group: "Catálogo", keywords: "massa lista colar lote" },
  { href: "/admin/categorias", label: "Categorias", description: "Grupos e nomes alternativos", icon: "categories", group: "Catálogo", keywords: "mapear imagem alias" },
  { href: "/admin/midia", label: "Imagens", description: "Biblioteca e arquivos", icon: "media", group: "Catálogo", keywords: "upload storage capa" },
  { href: "/admin/editor", label: "Página inicial", description: "Seções, textos e ordem", icon: "layout", group: "Conteúdo", keywords: "home vitrine carrossel" },
  { href: "/admin/banners", label: "Banners", description: "Campanhas e destaques", icon: "banner", group: "Conteúdo", keywords: "slider anúncio" },
  { href: "/admin/navegacao", label: "Redes sociais", description: "Menus, links e redes", icon: "navigation", group: "Conteúdo", keywords: "instagram tiktok shopee whatsapp" },
  { href: "/admin/paginas", label: "Páginas", description: "Sobre, políticas e textos", icon: "text", group: "Conteúdo", keywords: "privacidade termos" },
  { href: "/admin/aparencia", label: "Aparência", description: "Marca, cores e componentes", icon: "palette", group: "Crescimento", keywords: "tema visual logo" },
  { href: "/admin/analytics", label: "Analytics", description: "Cliques, visitas e buscas", icon: "chart", group: "Crescimento", keywords: "dados pesquisa" },
  { href: "/admin/controle", label: "Controle", description: "Publicação, catálogo e backup", icon: "shield", group: "Sistema", keywords: "manutenção reset exportar" },
  { href: "/admin/atividade", label: "Atividades", description: "Histórico de alterações", icon: "calendar", group: "Sistema", keywords: "logs auditoria" },
  { href: "/admin/configuracoes", label: "Configurações", description: "Marca, domínio e SEO", icon: "settings", group: "Sistema", keywords: "favicon seo domínio" },
];

const groups: Group[] = ["Início", "Catálogo", "Conteúdo", "Crescimento", "Sistema"];

export default function AdminShell({ children }: { children: ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [ready, setReady] = useState(false);
  const [error, setError] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [commandOpen, setCommandOpen] = useState(false);
  const [commandQuery, setCommandQuery] = useState("");
  const [brand, setBrand] = useState({ name: "H&S Achadinhos", logo: "/brand/hs-monogram.svg", email: "", maintenance: false });

  useEffect(() => {
    const supabase = getBrowserSupabase();
    if (!supabase) {
      setError("Configure as variáveis do Supabase.");
      setReady(true);
      return;
    }

    let active = true;
    void (async () => {
      const { data: sessionData } = await supabase.auth.getSession();
      const user = sessionData.session?.user;
      if (!user) {
        router.replace(`/admin/login?next=${encodeURIComponent(pathname)}`);
        return;
      }

      const [{ data: profile }, { data: settings }] = await Promise.all([
        supabase.from("profiles").select("role").eq("id", user.id).maybeSingle(),
        supabase.from("site_settings").select("key,value").in("key", ["site_name", "logo_url", "maintenance_mode"]),
      ]);

      if (!active) return;
      if (profile?.role !== "admin") {
        await supabase.auth.signOut();
        router.replace("/admin/login?error=unauthorized");
        return;
      }

      const values = Object.fromEntries((settings ?? []).map((item) => [item.key, item.value]));
      setBrand({
        name: String(values.site_name || "H&S Achadinhos"),
        logo: String(values.logo_url || "/brand/hs-monogram.svg"),
        email: user.email || "",
        maintenance: Boolean(values.maintenance_mode),
      });
      setReady(true);
    })();

    return () => { active = false; };
  }, [pathname, router]);

  useEffect(() => {
    setMobileOpen(false);
    setCommandOpen(false);
    setCommandQuery("");
  }, [pathname]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setCommandOpen((current) => !current);
      }
      if (event.key === "Escape") {
        setCommandOpen(false);
        setMobileOpen(false);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  function activeRoute(href: string) {
    if (href === "/admin") return pathname === href;
    if (href === "/admin/produtos") return pathname === href;
    return pathname === href || pathname.startsWith(`${href}/`);
  }

  const activeItem = useMemo(() => navItems.find((item) => activeRoute(item.href)) || navItems[0], [pathname]);
  const commandResults = useMemo(() => {
    const query = commandQuery.trim().toLowerCase();
    if (!query) return navItems;
    return navItems.filter((item) => `${item.label} ${item.description} ${item.keywords || ""}`.toLowerCase().includes(query));
  }, [commandQuery]);
  const mobilePrimary = ["/admin", "/admin/produtos", "/admin/categorias", "/admin/editor"]
    .map((href) => navItems.find((item) => item.href === href)!)
    .filter(Boolean);

  async function logout() {
    const supabase = getBrowserSupabase();
    await supabase?.auth.signOut();
    router.replace("/admin/login");
  }

  if (!ready) {
    return (
      <div className="hst-loading-screen">
        <span><img src="/brand/hs-monogram.svg" alt="" /></span>
        <div><strong>Abrindo o H&S Studio</strong><small>Preparando suas ferramentas...</small></div>
      </div>
    );
  }

  if (error) return <main className="hst-error-page"><div className="error">{error}</div></main>;

  return (
    <div className="hst-shell">
      <aside className="hst-sidebar">
        <div className="hst-sidebar-pattern" aria-hidden="true" />
        <Link className="hst-brand" href="/admin">
          <span><img src={brand.logo} alt="" /></span>
          <div><strong>{brand.name}</strong><small>H&S Studio</small></div>
        </Link>

        <button className="hst-command-trigger" onClick={() => setCommandOpen(true)}>
          <Icon name="search" size={17} />
          <span>Encontrar uma função</span>
          <kbd>⌘K</kbd>
        </button>

        <nav className="hst-nav" aria-label="Painel administrativo">
          {groups.map((group) => (
            <section key={group}>
              <small>{group}</small>
              {navItems.filter((item) => item.group === group).map((item) => (
                <Link className={activeRoute(item.href) ? "active" : ""} href={item.href} key={item.href}>
                  <span><Icon name={item.icon} /></span>
                  <div><b>{item.label}</b><em>{item.description}</em></div>
                  <i />
                </Link>
              ))}
            </section>
          ))}
        </nav>

        <div className="hst-account">
          <span>{brand.email.slice(0, 1).toUpperCase() || "A"}</span>
          <div><strong>Conta principal</strong><small>{brand.email || "Administrador"}</small></div>
          <button onClick={() => void logout()} aria-label="Sair"><Icon name="logout" size={18} /></button>
        </div>
      </aside>

      <div className="hst-workspace">
        <header className="hst-topbar">
          <button className="hst-mobile-menu-button" onClick={() => setMobileOpen(true)} aria-label="Abrir menu"><Icon name="menu" /></button>
          <div className="hst-page-context">
            <span>{activeItem.group}</span>
            <strong>{activeItem.label}</strong>
            <small>{activeItem.description}</small>
          </div>
          <button className="hst-top-search" onClick={() => setCommandOpen(true)}><Icon name="search" size={17} /><span>Buscar no painel</span><kbd>Ctrl K</kbd></button>
          <div className="hst-top-actions">
            <Link className={`hst-site-status ${brand.maintenance ? "paused" : ""}`} href="/admin/controle"><i />{brand.maintenance ? "Em manutenção" : "Publicado"}</Link>
            <Link className="hst-view-site" href="/" target="_blank"><Icon name="eye" size={18} /><span>Ver site</span></Link>
          </div>
        </header>

        <main className="hst-main">
          <div className="hst-main-watermark" aria-hidden="true">H&S</div>
          {children}
        </main>
      </div>

      <nav className="hst-bottom-nav" aria-label="Navegação rápida">
        {mobilePrimary.map((item) => (
          <Link className={activeRoute(item.href) ? "active" : ""} href={item.href} key={item.href}>
            <span><Icon name={item.icon} /></span><b>{item.label.split(" ")[0]}</b>
          </Link>
        ))}
        <button className={mobileOpen ? "active" : ""} onClick={() => setMobileOpen(true)}><span><Icon name="more" /></span><b>Mais</b></button>
      </nav>

      {mobileOpen ? (
        <div className="hst-mobile-backdrop" onMouseDown={() => setMobileOpen(false)}>
          <aside className="hst-mobile-sheet" onMouseDown={(event) => event.stopPropagation()}>
            <div className="hst-mobile-handle" />
            <header>
              <div><span>H&S STUDIO</span><strong>O que deseja editar?</strong></div>
              <button onClick={() => setMobileOpen(false)}><Icon name="close" /></button>
            </header>
            <button className="hst-mobile-search" onClick={() => { setMobileOpen(false); setCommandOpen(true); }}><Icon name="search" />Buscar função</button>
            <div className="hst-mobile-links">
              {navItems.map((item) => (
                <Link className={activeRoute(item.href) ? "active" : ""} href={item.href} key={item.href}>
                  <span><Icon name={item.icon} /></span>
                  <div><b>{item.label}</b><small>{item.description}</small></div>
                  <Icon name="arrow" size={16} />
                </Link>
              ))}
            </div>
            <footer><Link href="/" target="_blank"><Icon name="external" />Abrir site</Link><button onClick={() => void logout()}><Icon name="logout" />Sair</button></footer>
          </aside>
        </div>
      ) : null}

      {commandOpen ? (
        <div className="hst-command-backdrop" onMouseDown={() => setCommandOpen(false)}>
          <section className="hst-command-palette" onMouseDown={(event) => event.stopPropagation()}>
            <header><Icon name="search" /><input autoFocus value={commandQuery} onChange={(event) => setCommandQuery(event.target.value)} placeholder="Digite o que deseja editar..." /><button onClick={() => setCommandOpen(false)}>ESC</button></header>
            <div>
              {commandResults.map((item) => (
                <Link href={item.href} key={item.href}><span><Icon name={item.icon} /></span><div><strong>{item.label}</strong><small>{item.description}</small></div><Icon name="arrow" size={16} /></Link>
              ))}
              {!commandResults.length ? <div className="hst-command-empty">Nenhuma função encontrada.</div> : null}
            </div>
          </section>
        </div>
      ) : null}
    </div>
  );
}
