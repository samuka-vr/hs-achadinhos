# Atualização V13 — Reconstrução total das interfaces

## Antes de começar

Crie um commit da versão atual. Esta atualização não exige SQL e não apaga produtos ou configurações.

## Arquivo recomendado

Use `hs-achadinhos-v13-reconstrucao-total-patch.zip` sobre o projeto atual.

## Comandos no Codespaces

```bash
git status
git add .
git commit -m "Salvar versão antes da V13" || true

git pull --rebase origin main

rm -f src/app/\(site\)/public-redesign.css
rm -f src/app/styles/public-attractive-v12.css
rm -f src/app/styles/admin-attractive-v12.css

unzip -o hs-achadinhos-v13-reconstrucao-total-patch.zip
rm hs-achadinhos-v13-reconstrucao-total-patch.zip

npm install
npm run typecheck
npm run build

git add .
git commit -m "Reconstruir interfaces H&S V13"
git pull --rebase origin main
git push origin main
```

## O que conferir no Preview da Vercel

### Site público

- home em 360 px, 390 px e 430 px;
- menu, busca, carrossel e categorias;
- um card completo por vez no carrossel mobile;
- ausência de rolagem horizontal;
- catálogo, busca, categoria e produto;
- links da Shopee e redes sociais.

### Painel

- login;
- dashboard;
- produtos em cartões;
- troca rápida de foto;
- filtros e seleção em massa;
- editor de produto;
- importador;
- categorias e aliases;
- mídia, página inicial, banners, aparência, analytics e configurações.

## Rollback

Na Vercel, abra o deploy anterior e escolha a opção de promover novamente. No GitHub, também é possível reverter o commit da V13:

```bash
git revert HEAD
git push origin main
```
