import "../styles/admin-attractive-v12.css";

export default function AdminRootLayout({ children }: { children: React.ReactNode }) {
  return children;
}
