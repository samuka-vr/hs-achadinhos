# H&S Achadinhos V12 — Interfaces mais atraentes

Esta atualização reconstrói visualmente as duas áreas sem alterar o banco de dados ou os mecanismos do catálogo.

## Site público — Boutique de Achados

- novo fundo quente com rosa, creme, lilás e pêssego;
- cabeçalho com marca mais forte;
- hero em painel editorial chamativo;
- busca com maior contraste;
- carrossel preservado, com um card completo por vez no mobile;
- categorias em painel colorido;
- cards de produto com mais contraste e hierarquia;
- seções alternadas e rodapé mais marcante.

## Painel — H&S Studio

- sidebar vinho com identidade própria;
- cabeçalho e áreas de trabalho mais claros;
- títulos em painéis visuais;
- métricas com cores diferentes;
- formulários, cards e listas mais fáceis de identificar;
- produtos mobile com faixa visual e ações mais táteis;
- navegação inferior e menu mobile reformulados;
- login administrativo reconstruído.

## Banco de dados

Nenhuma migration ou SQL novo é necessário.

## Instalação

Use o ZIP completo ou o patch. Depois execute:

```bash
npm install
npm run typecheck
npm run build
git add .
git commit -m "Refazer interfaces H&S V12"
git pull --rebase origin main
git push origin main
```
